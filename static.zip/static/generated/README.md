This directory is for generated static assets such as emoji.
