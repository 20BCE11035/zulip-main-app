# Code testing

```{toctree}
---
maxdepth: 3
---

testing
linters
testing-with-django
testing-with-node
testing-with-puppeteer
mypy
typescript
continuous-integration
manual-testing
philosophy
```
