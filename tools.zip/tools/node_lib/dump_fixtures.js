"use strict";

const events = require("../../web/tests/lib/events");

console.info(JSON.stringify(events.fixtures, null, 4));
