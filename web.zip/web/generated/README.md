This directory is for generated frontend assets.
