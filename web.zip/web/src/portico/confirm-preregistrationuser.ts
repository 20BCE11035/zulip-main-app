import $ from "jquery";

$(() => {
    $("#register").trigger("submit");
});
