This directory contains icons used by the Zulip web app that are not
part of Font Awesome 4.7, our default/primary icon font.

Icons placed in this directory are compiled by the web application
build system into a custom icon font. You can use them in HTML using
the following syntax:

`<i class="zulip-icon zulip-icon-more-vertical">`
