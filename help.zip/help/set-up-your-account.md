# Set up your account

{!set-up-your-account.md!}

## Related articles

* [Getting started with Zulip](/help/getting-started-with-zulip)
* [Review your settings](/help/review-your-settings)
