# Collaborative to-do lists

{!to-do-lists-intro.md!}

## Examples

{!to-do-lists-examples.md!}

## Related articles

* [Message formatting](/help/format-your-message-using-markdown)
* [Polls](/help/create-a-poll)
