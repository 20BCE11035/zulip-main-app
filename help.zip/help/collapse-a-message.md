# Collapse a message

Collapse messages that you don't want to see. Zulip sometimes automatically
partially condenses long messages. This feature is different, and will fully
remove the message content from view.

### Collapse a message

{start_tabs}

{!message-actions-menu.md!}

3. Click **Collapse message**.

{end_tabs}

!!! tip ""
     To expand a message, click **Show more** at the bottom of the collapsed
     message.
