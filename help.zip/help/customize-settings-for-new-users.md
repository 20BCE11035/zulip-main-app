# Customize settings for new users

{!customize-settings-for-new-users.md!}

## Related articles

* [Setting up your organization](/help/getting-your-organization-started-with-zulip)
* [Invite users to join](/help/invite-users-to-join)
* [Getting started with Zulip](/help/getting-started-with-zulip)
