# All messages

{!all-messages.md!}

!!! keyboard_tip ""

    Use <kbd>S</kbd> (narrow to stream) or <kbd>Shift</kbd> +
    <kbd>S</kbd> (narrow to conversation) to zoom in, and <kbd>A</kbd> to
    get back to **All messages**.


## Related articles
* [Reading strategies](/help/reading-strategies)
* [Inbox](/help/inbox)
* [Recent conversations](/help/recent-conversations)
* [Configure home view](/help/configure-home-view)
* [Reading conversations](/help/reading-conversations)
