# Migrating from other chat tools

{!migrating-from-other-chat-tools.md!}

## Related articles

* [Zulip Cloud or self-hosting?](/help/zulip-cloud-or-self-hosting)
* [Trying out Zulip](/help/trying-out-zulip)
* [Self-hosting Zulip](/self-hosting/)
* [Installing a Zulip server](https://zulip.readthedocs.io/en/stable/production/install.html)
* [Setting up your organization](/help/getting-your-organization-started-with-zulip)
* [Getting started with Zulip](/help/getting-started-with-zulip)
