In Zulip, you can make text bold or italic, or cross it out with strikethrough.
