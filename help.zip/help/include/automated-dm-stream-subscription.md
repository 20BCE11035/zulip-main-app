!!! warn ""

      **Note**: Subscribing someone else to a stream sends them an
      automated direct message from [notification bot][notification-bot].

[notification-bot]: /help/configure-notification-bot
