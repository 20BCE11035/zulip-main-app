### What you type

```
:octopus: :heart: :zulip: :)
```

### What it looks like

![Markdown emoji](/static/images/help/markdown-emoji.png)
