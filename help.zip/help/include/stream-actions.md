1. Hover over a stream in the left sidebar.

1. Click on the **ellipsis** (<i class="zulip-icon zulip-icon-more-vertical"></i>).
