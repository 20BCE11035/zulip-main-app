{settings_tab|topics}

1. Configure notifications for each topic by selecting the desired option from
   the dropdown in the **Status** column.
