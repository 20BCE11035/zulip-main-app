### What you type

```
**bold**, *italic*, and ~~strikethrough~~ text
***~~All three at once~~***
```

### What it looks like

![Markdown emphasis](/static/images/help/markdown-emphasis.png)
