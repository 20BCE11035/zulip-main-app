1. Tap your **profile picture** in the bottom right corner of the app.
