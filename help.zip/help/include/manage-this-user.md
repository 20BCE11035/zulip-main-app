{!user-card-three-dot-menu.md!}

1. Click **Manage this user**.
