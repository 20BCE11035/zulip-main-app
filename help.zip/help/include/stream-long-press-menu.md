1. Press and hold a stream until the long-press menu appears.
