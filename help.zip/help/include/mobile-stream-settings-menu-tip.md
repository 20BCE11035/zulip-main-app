!!! tip ""

    If you are in a stream view, you can access the
    stream settings menu from the **information**
    (<img src="/static/images/help/mobile-info-circle-icon.svg" alt="information" class="help-center-icon"/>)
    button in the top right corner of the app.
