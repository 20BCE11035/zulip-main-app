1. Press and hold a stream name until the long-press menu appears.
