To perform this export, your organization must meet the following requirements:

- You are a paid [Zulip Cloud Standard][standard] customer. In rare cases,
  exceptions may be made in case of due legal process.

- You have authority to read members' [direct messages](/help/direct-messages).
  Typically, this will be because your Zulip organization is administered by a
  corporation, and you are an official representative of that corporation.

By requesting and approving this export, you will assume full legal
responsibility that the appropriate employment agreements and corporate policy
for this type of export are in place. Note that many countries have laws that
require employers to notify employees of their use of such an export.
