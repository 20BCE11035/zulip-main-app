User groups allow you to [mention](/help/mention-a-user-or-group) multiple users
at once. When you mention a user group, everyone in the group is
[notified](/help/dm-mention-alert-notifications) as if they were personally
mentioned. For example, you may choose to create user groups for teams in your
organization.
