1. How you would like the Zulip log in button to be labeled: “Log in with...”
1. *(optional)* An icon to use on the log in button
