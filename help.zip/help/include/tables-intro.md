Zulip supports Markdown formatting for tables.
