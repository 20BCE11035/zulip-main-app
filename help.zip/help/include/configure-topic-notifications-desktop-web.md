{!topic-actions.md!}

1. Configure topic notifications using the row of icons at the top of the menu.

!!! tip ""

    You can also configure notifications by clicking the topic notifications
    status icon (<i class="zulip-icon zulip-icon-mute-new"></i>,
    <i class="zulip-icon zulip-icon-unmute-new"></i>, or
    <i class="zulip-icon zulip-icon-follow"></i>) in the message recipient bar,
    in the **Inbox view**, or in **Recent conversations**.
