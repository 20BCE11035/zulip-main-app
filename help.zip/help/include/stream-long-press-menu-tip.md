!!! tip ""

    If you are in a stream view, you can access the long-press
    menu from the bar at the top of the app.
