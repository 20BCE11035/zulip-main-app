### What you type

```
* bulleted lists
  * with sub-bullets too
  * sub-bullets start with 2 spaces
    * start sub-sub-bullets with 4 spaces
* multi
line
bullet
- dashes and
+ pluses are ok too
```

### What it looks like

![Markdown bullets](/static/images/help/markdown-bullets.png)
