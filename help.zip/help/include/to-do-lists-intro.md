Zulip supports creating shared to-do lists where any user who can access the
message can add tasks by entering the task's title and description, and clicking
**Add task**. Once created, task titles and descriptions cannot be edited.
