It generally works best to read your messages organized by conversation.
