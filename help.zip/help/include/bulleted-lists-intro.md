Zulip supports Markdown formatting for bulleted lists.
You can create bulleted lists using `*`, `-`, or `+` at the start of each line.
Add two spaces before the bullet to create a nested list.
