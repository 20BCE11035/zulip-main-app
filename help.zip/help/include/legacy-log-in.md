1. Go to <https://selfhosting.zulip.com/serverlogin/>.

1. Fill out the requested server information, and click **Continue**.

1. Enter the e-mail address of the billing contact for your organization,
   and click **Confirm email**.

**Billing administrator steps:**

1. In your e-mail account, open the e-mail you received
   (Subject: Log in to Zulip plan management), and click **Log in**.

1. Verify your information, and click **Continue**. If you are logging in for
   the first time, you will need to enter your name and accept the [Terms of
   Service](https://zulip.com/policies/terms).
