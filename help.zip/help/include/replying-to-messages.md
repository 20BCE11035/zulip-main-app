To reply to an existing thread:

{start_tabs}

1. Click the **Message...** button at the bottom of the app.

1. Compose your message. You
   can [preview your message](/help/preview-your-message-before-sending) before
   sending.

1. Click the **Send** (<i class="zulip-icon zulip-icon-send"></i>) button, or
   use a [keyboard shortcut](/help/mastering-the-compose-box#toggle-between-ctrl-enter-and-enter-to-send-a-message)
   to send your message.

!!! tip ""
    You can also reply by clicking on a message, or using the <kbd>R</kbd> or
    <kbd>Enter</kbd> keyboard shortcuts to reply to the message in the blue box.

{end_tabs}
