1. Click on <i class="zulip-icon zulip-icon-inbox"></i> **Inbox**
   (or <i class="zulip-icon zulip-icon-inbox"></i> if the **views**
   section is collapsed) in the left sidebar,
   or use the <kbd>Shift</kbd> + <kbd>I</kbd> keyboard shortcut.
