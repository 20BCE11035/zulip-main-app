{!send-dm.md!}

!!! tip ""

    Rather than kicking off a group direct message, consider starting the
    conversation in a new topic to make it easier to browse later on.
