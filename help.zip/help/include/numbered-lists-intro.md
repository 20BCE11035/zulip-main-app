Zulip supports Markdown formatting for numbered lists.
You can create numbered lists by putting a number followed by a `.` at the start
of each line. Lists are numbered automatically, so you can reorder list items
while editing your message without having to update the numbers. Add two spaces
before the number to create a nested list.
