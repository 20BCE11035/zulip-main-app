1. Tap the **Streams**
   (<img src="/static/images/help/mobile-hash-icon.svg" alt="hash" class="help-center-icon"/>)
   tab at the bottom of the app.

1. Scroll down to the bottom, and tap **ALL STREAMS**.
