1. Click on the **gear** (<i class="zulip-icon zulip-icon-gear"></i>) icon in
   the upper right corner of the web or desktop app.

1. Select <i class="zulip-icon zulip-icon-rocket"></i> **Plan management**.

1. *(first-time log in)* Enter the e-mail address you want to use for plan
   management, and click **Continue**.

1. *(first-time log in)* In your e-mail account, open the e-mail you received
   (Subject: Confirm email for Zulip plan management), and click **Confirm and
   log in**.

1. *(first-time log in)* Enter your name, configure your email preferences, and
   accept the [Terms of Service](https://zulip.com/policies/terms).

1. Verify your information, and click **Continue**.
