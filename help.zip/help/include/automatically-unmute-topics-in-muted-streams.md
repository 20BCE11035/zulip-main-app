{start_tabs}

{tab|desktop-web}

{settings_tab|notifications}

1. Under **Topic notifications**, select the desired option from the
   **Automatically unmute topics in muted streams** dropdown.

{end_tabs}
