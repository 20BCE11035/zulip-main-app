1. Click on <i class="zulip-icon zulip-icon-clock"></i> **Recent conversations**
   (or <i class="zulip-icon zulip-icon-clock"></i> if the **views**
   section is collapsed) in the left sidebar,
   or use the <kbd>T</kbd> keyboard shortcut.
