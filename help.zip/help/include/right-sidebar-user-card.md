1. Hover over a user's name in the right sidebar.

1. Click on the **ellipsis** (<i class="zulip-icon zulip-icon-more-vertical"></i>)
   to the right of their name to open their **user card**.
