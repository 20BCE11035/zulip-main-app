### What you type

```
One blank space for a new paragraph
New line, same paragraph

New paragraph

---, ***, or ___ for a horizontal line
Over the line

---

Under the line
```

### What it looks like

![Markdown paragraph](/static/images/help/markdown-paragraph.png)
