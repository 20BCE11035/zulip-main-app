You can format quotes one line at a time, or create a block of text that will be
formatted as a quote.
