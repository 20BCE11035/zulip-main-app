### What you type

```
1. numbered lists
1. increment automatically
   1. use nested lists if you like
   3. delete or reorder lines without fixing the numbering
1. one more
   17. lists can start at any number
   18. so you can continue a list after some other text
```

### What it looks like

![Markdown numbered lists](/static/images/help/markdown-numbered-lists.png)
