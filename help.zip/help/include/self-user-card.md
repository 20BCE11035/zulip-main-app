1. Hover over your name in the right sidebar.

1. Click on the **ellipsis** (<i class="zulip-icon zulip-icon-more-vertical"></i>)
   to open your **user card**.
