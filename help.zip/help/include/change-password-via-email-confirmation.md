{start_tabs}

1. If you are logged in, start by [logging out](/help/logging-out).

2. Go to your organization's login page at `https://<organization-url>/login/`.

3. Click the **Forgot your password?** link below the **Log in** button or
   buttons.

4. Enter your email address, and click **Send reset link**.

5. You will receive a confirmation email within a few minutes. Open it and click
   **Reset password**.

{end_tabs}
