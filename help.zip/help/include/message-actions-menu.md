1. Hover over a message to reveal three icons on the right.

1. Click on the **ellipsis** (<i class="zulip-icon zulip-icon-more-vertical-spread"></i>).
