### What you type

~~~
> a multi-line
quote on two lines

normal text

```quote
A multi-paragraph

quote in two paragraphs
```
~~~

### What it looks like

![Markdown quotes](/static/images/help/markdown-quotes.png)
