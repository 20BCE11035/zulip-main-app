{start_tabs}

{settings_tab|organization-profile}

1. To be listed in the appropriate category, under **Organization type**, select
the option that best fits your organization.

1. Toggle **Advertise organization in the Zulip communities
directory**.

{!save-changes.md!}

{end_tabs}
