{start_tabs}

{tab|desktop-web}

{relative|gear|stream-settings}

1. Click **Create stream** on the right, or click the **plus**
   (<i class="fa fa-plus"></i>) icon in the upper right.

1. Fill out the requested info, and click **Create** in the bottom right corner
   of the create stream panel.

!!! warn ""

    **Note**: You will only see the **Create stream** button if you have
    permission to create streams.

{tab|mobile}

{!mobile-all-streams-view.md!}

1. Tap the **Create new stream** button at the top of the app.

1. Fill out the requested info, and tap **Create**.

!!! warn ""

    **Note**: You will only see the **Create new stream** button if you have
    permission to create streams.

{end_tabs}
