1. Click on the compose box, or press <kbd>Tab</kbd> to compose your message. You
   can [preview your message](/help/preview-your-message-before-sending) before
   sending.

1. Click the **Send** (<i class="zulip-icon zulip-icon-send"></i>) button, or
   use a [keyboard shortcut](/help/mastering-the-compose-box#toggle-between-ctrl-enter-and-enter-to-send-a-message)
   to send your message.
