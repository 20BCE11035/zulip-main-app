{!right-sidebar-user-card.md!}

1. Click on the **ellipsis** (<i class="zulip-icon zulip-icon-more-vertical"></i>) in the user card.
