1. Click on the **gear** (<i class="fa fa-cog"></i>) icon in the upper
   right corner of the web or desktop app.

1. Select <i class="fa fa-user-plus"></i> **Invite users**.
