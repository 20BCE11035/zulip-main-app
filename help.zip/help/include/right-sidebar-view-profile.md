{!right-sidebar-user-card.md!}

1. Click **View profile**.
