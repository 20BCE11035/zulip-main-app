You can send messages that display your profile picture and name as the
beginning of the message content by beginning a message with `/me`. You can
use this feature in conversations when you want to describe actions you've
taken or things that are happening around you using a third-person voice.
