{start_tabs}

{tab|desktop-web}

1. Click on <i class="zulip-icon zulip-icon-star-filled"></i> **Starred messages**
   (or <i class="zulip-icon zulip-icon-star-filled"></i> if the **views**
   section is collapsed) in the left sidebar.

!!! tip ""

    You can also [search your starred messages](/help/search-for-messages)
    using the `is:starred` filter.

{tab|mobile}

1. Tap the **Starred messages**
   (<img src="/static/images/help/mobile-star-icon.svg" alt="star" class="help-center-icon"/>)
   tab at the top of the app.

{end_tabs}
