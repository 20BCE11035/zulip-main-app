{!right-sidebar-view-profile.md!}

1. Select the **Manage user** tab, or click the **pencil and paper**
   (<i class="fa fa-edit"></i>) icon next to the user's name.
