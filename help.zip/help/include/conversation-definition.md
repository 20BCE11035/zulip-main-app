In Zulip, a **conversation** is a [direct message](/help/direct-messages) thread
(one-on-one or with a group), or a [topic in a
stream](/help/streams-and-topics).
