You can use emoji in Zulip messages and [topics](/help/streams-and-topics).
There are several ways to use an emoji in your message:

- [Enter an emoji name](/help/emoji-and-emoticons#use-an-emoji-in-your-message)
  surrounded by `:`, with help from autocomplete suggestions.

- [Select an emoji from the emoji
  picker](/help/emoji-and-emoticons#use-an-emoji-in-your-message)

- [Use an emoticon](/help/emoji-and-emoticons#use-an-emoticon)

- [Paste an emoji](/help/emoji-and-emoticons#use-an-emoji-in-your-message)

You can [add custom emoji](/help/custom-emoji) for your organization. Like
default emoji, custom emoji can be entered into the compose box by name, or
selected from the emoji picker.
