### What you type

```
Named link: [Zulip homepage](zulip.com)
A URL (links automatically): zulip.com
Stream link: #**stream name**
Stream and topic link: #**stream name>topic name**
Custom linkifier: For example, #2468 can automatically link to an issue in your tracker.
```

### What it looks like

![Markdown links](/static/images/help/markdown-links.png)
