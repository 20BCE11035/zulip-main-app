1. Hover over a message to reveal three icons on the right.
