1. [Open the compose box](/help/open-the-compose-box).
