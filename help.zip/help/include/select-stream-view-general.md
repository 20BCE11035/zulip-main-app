1. Select the **General** tab on the right.
