In Zulip, you can insert a named link using Markdown formatting. In addition, Zulip
automatically creates links for you when you enter:

- A URL
- An appropriately formatted stream name, or a stream name followed by a topic
  (see also [Link to a message or
  conversation](/help/link-to-a-message-or-conversation))
- Text that matches a [custom linkifier](/help/add-a-custom-linkifier) set up by your organization
