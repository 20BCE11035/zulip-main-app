{start_tabs}

{tab|desktop-web}

{settings_tab|notifications}

1. In the **Notification triggers** table,
   toggle the settings for **Followed topics**.

{end_tabs}

!!! tip ""

    You will receive both followed topics notifications and
    [stream notifications](/help/stream-notifications) in topics you follow.
