### What you type

```
Users: @**Bo Lin** or @**Ariella Drake|26** (two `*`)
User group: @*support team* (one `*`)
Silent mention: @_**Bo Lin** or @_**Ariella Drake|26** (`@_` instead of `@`)
Wildcard mentions: @**all**, @**everyone**, @**stream**, or @**topic** (two `*`)
```

!!! tip ""

    A `|` followed by a user ID is inserted automatically when you select a
    user from the typeahead suggestions, if there are two users with the same
    name in the organization.

### What it looks like

![Markdown mentions](/static/images/help/markdown-mentions.png)
