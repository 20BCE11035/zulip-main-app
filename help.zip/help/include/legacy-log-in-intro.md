!!! tip ""

    A **server administrator** is anyone who sets up and manages your Zulip
    installation. A **billing administrator** is anyone responsible for managing
    your Zulip plan.

**Server administrator steps:**
