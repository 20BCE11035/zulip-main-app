!!! tip ""

    If you are viewing a direct message conversation, you can also tap the
    **information**
    (<img src="/static/images/help/mobile-info-circle-icon.svg" alt="information" class="help-center-icon"/>)
    button in the top right corner of the app to open their profile.
