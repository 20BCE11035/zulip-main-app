1. Click **Save changes**.
