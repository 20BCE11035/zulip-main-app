In the web app, the left sidebar provides quick access to your direct messages,
and the streams you are subscribed to.

{start_tabs}

{tab|desktop-web}

1. Click on **DIRECT MESSAGES** or the name of a stream in the left sidebar. You
   will see a list of the most recent unread conversations that you have not [muted](/help/mute-a-topic).

1. Click on the conversation you are interested in.

!!! tip ""

    To see all conversations, click on **more conversations** (in direct messages) or **more topics**
    (in a stream).

{end_tabs}
