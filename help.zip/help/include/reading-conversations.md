{start_tabs}

{tab|desktop-web}

1. [Find](/help/finding-a-conversation-to-read) a conversation to read.

1. Read the conversation, scrolling down with the mouse or by pressing
   <kbd>PgDn</kbd>.

1. If the conversation is not of interest, you can
   [mark all messages as read](/help/marking-messages-as-read) by
   jumping to the bottom with the **Scroll to bottom**
   (<i class="fa fa-chevron-down"></i>) button or the <kbd>End</kbd> shortcut.

!!! keyboard_tip ""

    Use the <kbd>N</kbd> key to go to the next unread topic, or <kbd>Shift</kbd> + <kbd>N</kbd>
    for the next unread [followed](/help/follow-a-topic) topic, or <kbd>P</kbd> for the next
    unread direct message conversation.

{end_tabs}
