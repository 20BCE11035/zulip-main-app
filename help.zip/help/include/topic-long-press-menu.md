1. Press and hold a topic until the long-press menu appears.
