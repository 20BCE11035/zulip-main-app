1. Select the **Personal** tab on the right.
