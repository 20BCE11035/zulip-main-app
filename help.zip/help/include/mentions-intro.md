You can mention a team member or [user group](/help/user-groups) to call their
attention to a message. Mentions follow the same [notification
settings](/help/dm-mention-alert-notifications) as direct messages and alert
words. A [silent mention](/help/mention-a-user-or-group#silently-mention-a-user)
allows you to refer to a user without triggering a notification. A wildcard
mention allows you to
[mention everyone on a stream](/help/mention-a-user-or-group#mention-everyone-on-a-stream),
or [mention all topic participants](/help/mention-a-user-or-group#mention-all-topic-participants).
