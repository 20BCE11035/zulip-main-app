!!! tip ""

    You can also press and hold the name of a stream in Inbox and stream views
    to access the long-press menu.
