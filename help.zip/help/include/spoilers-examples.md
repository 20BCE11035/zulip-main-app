### What you type

~~~

```spoiler The spoiler heading might summarize what's inside
This content is initially hidden.

> You can combine spoilers with other formatting.

```

A message can contain both spoilers and other content.

```spoiler
Leave the heading blank if you like.
```

~~~

### What it looks like

Collapsed spoilers:

![Spoiler collapsed](/static/images/help/spoiler-collapsed.png)

Expanded spoilers:

![Spoiler expanded](/static/images/help/spoiler-expanded.png)
