1. Register the server with Zulip's Mobile Push Notification Service, following
   [these
   instructions](https://zulip.readthedocs.io/en/latest/production/mobile-push-notifications.html).
