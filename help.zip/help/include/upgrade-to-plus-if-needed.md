1. Make sure your Zulip Cloud organization is on the [Zulip Cloud
   Plus](https://zulip.com/plans/) plan.
