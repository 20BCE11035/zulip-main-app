!!! tip ""

    You can also access the **Manage user** tab by clicking the **pencil and
    paper** (<i class="fa fa-edit"></i>) icon at the top of the [user
    profile](/help/view-someones-profile).
