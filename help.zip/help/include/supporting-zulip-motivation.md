Zulip sponsors free [Zulip Cloud Standard](https://zulip.com/plans/) hosting for
hundreds of worthy organizations. Zulip has also invested into making it as easy
as possible to [self-host](https://zulip.com/self-hosting/) its [100%
open-source](https://github.com/zulip/zulip#readme) software. Read about the
[Zulip project values](https://zulip.com/values/) to learn more.
