**Inbox** provides an overview of your conversations with unread messages.
Conversations are shown in the same order as in the left sidebar in the web app,
and you can collapse any streams you are not currently interested in.
