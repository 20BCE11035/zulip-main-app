!!! warn ""

    **Note**: This sends an automated notice from [notification
    bot][notification-bot] to the "stream events" topic in the
    modified stream.

[notification-bot]: /help/configure-notification-bot
