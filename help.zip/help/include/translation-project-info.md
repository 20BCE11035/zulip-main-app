Zulip has been translated or partially translated into dozens of
languages by Zulip's amazing community of volunteer translators.
You can see which languages Zulip supports [on Transifex][transifex-zulip].

If you'd like to help by contributing as a translator, see the
[Zulip translation guidelines][translating-zulip] to get started.

[transifex-zulip]: https://explore.transifex.com/zulip/zulip/
[translating-zulip]: https://zulip.readthedocs.io/en/stable/translating/translating.html
