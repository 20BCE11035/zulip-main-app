With manual billing, you choose and pay for a preset user limit. If
the limit is reached, no more users can join until licenses are manually
added.
