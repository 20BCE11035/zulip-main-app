{start_tabs}

{tab|desktop-web}

{!configure-topic-notifications-desktop-web.md!}

{tab|mobile}

{!topic-long-press-menu.md!}

1. Tap **Mute topic** or **Unmute topic**.

{!topic-long-press-menu-tip.md!}

{end_tabs}
