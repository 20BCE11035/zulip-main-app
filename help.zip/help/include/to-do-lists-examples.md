### What you type

```
/todo
```

!!! warn ""

    Any other content in a message starting with `/todo` will be ignored.

### What it looks like

After two tasks have been added to the shared to-do list:

![Markdown todo-lists](/static/images/help/markdown-todo.png)

!!! tip ""

    Tasks can be marked (and unmarked) as completed by clicking the
    checkboxes on the left.
