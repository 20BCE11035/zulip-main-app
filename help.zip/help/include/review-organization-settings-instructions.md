Review the settings for your organization to set everything up how you
want it to be.

{start_tabs}

{relative|gear|organization-settings}

1. Click on the **Organization settings** and **Organization
   permissions** tabs, as well as any others that are of interest.

{end_tabs}
