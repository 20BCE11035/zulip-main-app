The information in your organization profile is displayed on your organization's
registration and login pages, and (optionally) in the [communities
directory](/help/communities-directory). Your **organization profile picture**
is also used for [switching between
organizations](/help/switching-between-organizations) in the Desktop app.
