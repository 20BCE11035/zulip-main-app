{start_tabs}

{tab|desktop-web}

1. Click on <i class="zulip-icon zulip-icon-at-sign"></i> **Mentions**
   (or <i class="zulip-icon zulip-icon-at-sign"></i> if the **views**
   section is collapsed) in the left sidebar.

1. Browse your mentions. You can click on a message recipient bar to go
   to the [conversation](/help/recent-conversations) where you were mentioned.

!!! tip ""

    You can also [search your mentions](/help/search-for-messages) using the
    `is:mentioned` filter.

{tab|mobile}

1. Tap the **Mentions**
   (<img src="/static/images/help/mobile-at-sign-icon.svg" alt="at-sign" class="help-center-icon"/>)
   tab at the top of the app.

1. Browse your mentions. You can tap on a message recipient bar to go
   to the conversation where you were mentioned.

{end_tabs}
