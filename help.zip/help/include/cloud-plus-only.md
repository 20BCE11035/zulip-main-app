!!! warn ""

    Zulip Cloud customers who wish to use this feature must upgrade to
    the [Zulip Cloud Plus](https://zulip.com/plans/) plan.
