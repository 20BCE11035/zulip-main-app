!!! tip ""

    To show or hide the **organizations sidebar** on the left, select
    **Toggle Sidebar** from the **View** menu in the top menu bar.
