You can import your current workspace into a Zulip organization. It's a great way
to preserve your workspace history when you migrate to Zulip, and to
make the transition easy for the members of your organization.

The import will include your organization's:

* **Name** and **Logo**
* **Message history**, including attachments and emoji reactions
* **Users**, including names, emails, roles, avatars, time zones, and custom profile fields
* **Channels**, including all user subscriptions
* **Custom emoji**
