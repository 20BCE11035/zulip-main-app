When collaborating with people in different time zones, you often need to
express a specific time clearly. In Zulip, rather than typing out your time
zone and having everyone translate the time in their heads, you can insert
a time, and it will be displayed to each user in their own time zone (just
like timestamps on Zulip messages).
