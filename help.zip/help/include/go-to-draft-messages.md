1. Click on <i class="zulip-icon zulip-icon-drafts"></i>**Drafts**
   in the left sidebar. If the **views** section is collapsed, click on
   the **ellipsis** (<i class="zulip-icon zulip-icon-more-vertical"></i>),
   and select <i class="zulip-icon zulip-icon-drafts"></i>**Drafts**.
