For example, if you are **Ada Starr**:

### What you type

```
/me is away
```

### What it looks like

![Markdown status](/static/images/help/markdown-status.png)
