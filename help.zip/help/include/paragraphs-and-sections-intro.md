Zulip supports Markdown formatting for paragraphs and visual section breaks,
which you can use to control the layout of your text and to visually separate
different sections of content.
