{start_tabs}

{tab|desktop-web}

{relative|gear|group-settings}

1. Click **Create user group** on the right, or click the **plus**
   (<i class="fa fa-plus"></i>) icon in the upper right.

1. Fill out the requested info, and click **Create** in the bottom right corner
   of the create user group panel.

!!! warn ""

    **Note**: You will only see the **Create user group** button if you have
    permission to create user groups.

{end_tabs}
