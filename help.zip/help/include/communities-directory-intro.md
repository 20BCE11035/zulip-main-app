The [Zulip communities directory](https://zulip.com/communities/) offers
publicly accessible [Zulip Cloud][zulip-cloud] organizations an opportunity to
be listed on the [Zulip website](https://zulip.com). It's a way for [open-source
projects](https://zulip.com/for/open-source/), [research
communities](https://zulip.com/for/research/), and
[others](https://zulip.com/for/communities/) to advertise their Zulip community
and support the Zulip project.

The directory will display your community's name, logo, and a link to you Zulip
chat. Other information from your [organization
profile](/help/create-your-organization-profile) and the size of your
organization may be included as well.

[zulip-cloud]: https://zulip.com/plans/
