!!! tip ""

    * The import could take several minutes to run,
      depending on how much data you're importing.

    * The server stop/restart commands are only
      necessary when importing on a server with minimal
      RAM, where an OOM kill might otherwise occur.
