Zulip lets you temporarily hide content in a collapsible **spoiler** section,
with only the header initially shown. Clicking on the header reveals the hidden
content.
