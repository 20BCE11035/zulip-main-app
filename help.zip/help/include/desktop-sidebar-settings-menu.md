1. Click the **gear** (<i class="fa fa-cog"></i>) icon in the bottom left corner of the app.
