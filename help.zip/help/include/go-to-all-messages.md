1. Click on <i class="zulip-icon zulip-icon-all-messages"></i> **All messages**
   (or <i class="zulip-icon zulip-icon-all-messages"></i> if the **views**
   section is collapsed) in the left sidebar,
   or use the <kbd>A</kbd> keyboard shortcut.
