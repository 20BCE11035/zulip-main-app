!!! warn ""

    If your server has more than one organization, upgrade to Zulip Server 8.0+
    to manage billing and plan upgrades separately for each organization. Older
    servers only support server-wide plan management.
