1. Your Zulip server administrator should register the server with Zulip's
   Mobile Push Notification Service, following [these
   instructions](https://zulip.readthedocs.io/en/latest/production/mobile-push-notifications.html).
