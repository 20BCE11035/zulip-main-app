1. Press and hold a message until the long-press menu appears.
