If you are using Zulip Cloud, we'll take it from here! Please e-mail
[support@zulip.com](mailto:support@zulip.com) with the following information:
