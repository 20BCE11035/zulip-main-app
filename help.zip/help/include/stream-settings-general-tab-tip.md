!!! tip ""

    You can also hover over a stream in the left sidebar, click on the
    **ellipsis** (<i class="zulip-icon zulip-icon-more-vertical"></i>), and
    select **Stream settings** to access the **General** tab.
