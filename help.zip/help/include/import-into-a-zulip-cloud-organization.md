#### Import into a Zulip Cloud organization

{!send-us-info.md!}

1. The subdomain you would like to use for your organization. Your Zulip chat will
   be hosted at `<subdomain>.zulipchat.com`.

1. The **exported data** file containing your workspace message history export.
