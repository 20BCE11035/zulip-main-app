!!! warn ""

    The format of this export is designed for importing into a self-hosted
    installation of Zulip. It is not designed to be human-readable.
