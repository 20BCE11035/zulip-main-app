# Customize organization settings

{!customize-organization-settings.md!}

## Related articles

* [Setting up your organization](/help/getting-your-organization-started-with-zulip)
* [Create your organization profile](/help/create-your-organization-profile)
* [Create streams](/help/create-streams)
* [Getting started with Zulip](/help/getting-started-with-zulip)
