# Change the time format

Based on your preference, Zulip can display times either in a 12-hour
format (e.g. 5:00 PM) or a 24-hour format (e.g. 17:00).

### Change the time format

{start_tabs}

{settings_tab|preferences}

1. Under **General**, select your preferred option from the
**Time format** dropdown.

{end_tabs}
