# Reading conversations

{!conversation-definition.md!}

{!conversation-recommendation.md!}

{!reading-conversations.md!}

## Related articles

* [Getting started with Zulip](/help/getting-started-with-zulip)
* [Finding a conversation to read](/help/finding-a-conversation-to-read)
* [Reading strategies](/help/reading-strategies)
