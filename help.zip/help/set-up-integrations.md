# Set up integrations

{!set-up-integrations.md!}

## Related articles

* [Integrations overview](/help/integrations-overview)
* [Setting up your organization](/help/getting-your-organization-started-with-zulip)
* [Bots overview](/help/bots-overview)
* [Add a bot or integration](/help/add-a-bot-or-integration)
* [Add a custom linkifier](/help/add-a-custom-linkifier)
