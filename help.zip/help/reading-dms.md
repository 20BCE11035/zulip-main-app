# Reading direct messages (DMs)

{!reading-dms.md!}

## Related articles

* [Getting started with Zulip](/help/getting-started-with-zulip)
* [Reading conversations](/help/reading-conversations)
* [Finding a conversations to read](/help/finding-a-conversation-to-read)
* [Reading strategies](/help/reading-strategies)
