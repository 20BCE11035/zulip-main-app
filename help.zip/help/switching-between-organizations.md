# Switching between organizations

This article assumes you've [logged in](/help/logging-in) to each organization at least once.

{!switching-between-organizations.md!}

## Related articles

* [Logging in](logging-in)
* [Logging out](logging-out)
* [Deactivate your account](deactivate-your-account)
* [Create your organization profile](create-your-organization-profile)
* [Joining a Zulip organization](/help/join-a-zulip-organization)
