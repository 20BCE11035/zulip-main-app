# Rename a stream

{!admin-only.md!}

{start_tabs}

{tab|desktop-web}

{relative|stream|all}

1. Select a stream.

{!select-stream-view-general.md!}

1. Click the **pencil** (<i class="fa fa-pencil"></i>) icon
   to the right of the stream name, and enter a new stream name.

{!save-changes.md!}

{!stream-settings-general-tab-tip.md!}

{tab|mobile}

{!mobile-all-streams-view.md!}

{!stream-name-long-press-menu.md!}

1. Tap **Stream settings**.

1. Tap **Edit stream**, and enter a new stream name.

1. Tap **Save**.

{!stream-name-long-press-menu-tip.md!}

{end_tabs}

{!automated-notice-stream-event.md!}
